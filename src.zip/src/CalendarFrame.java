import javax.swing.*;
import java.awt.*;
import java.time.*;
import java.time.format.TextStyle;
import java.util.Locale;

public class CalendarFrame extends JFrame {

    public CalendarFrame() {
        setTitle("Calendar 2025");
        setSize(450, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new GridLayout(3, 4, 10, 10));
        for (int month = 1; month <= 12; month++) {
            mainPanel.add(createMonthView(month, 2025));
        }

        add(new JScrollPane(mainPanel));
        setVisible(true);
    }

    private JPanel createMonthView(int month, int year) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        LocalDate date = LocalDate.of(year, month, 1);
        String title = date.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + year;
        JLabel titleLabel = new JLabel(title, JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(titleLabel, BorderLayout.NORTH);

        JPanel daysGrid = new JPanel(new GridLayout(0, 7));
        String[] headers = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        for (String day : headers) {
            JLabel label = new JLabel(day, JLabel.CENTER);
            label.setFont(new Font("Arial", Font.BOLD, 12));
            daysGrid.add(label);
        }

        int offset = date.getDayOfWeek().getValue() % 7;
        int daysInMonth = date.lengthOfMonth();

        for (int i = 0; i < offset; i++) {
            daysGrid.add(new JLabel(""));
        }
        for (int d = 1; d <= daysInMonth; d++) {
            daysGrid.add(new JLabel(String.valueOf(d), JLabel.CENTER));
        }

        panel.add(daysGrid, BorderLayout.CENTER);
        return panel;
    }
}
