import javax.swing.*;
import java.awt.*;
import java.util.*;

public class CourseManager {
public static final String[] COURSES = {"Java", "Python", "DBMS", "AI", "Networking"};

private static final Map<String, Integer> COURSE_CREDITS = Map.of(
"Java", 3,
"Python", 3,
"DBMS", 4,
"AI", 4,
"Networking", 3);
    

private static final Map<String, Integer> courseMarks = new HashMap<>();
private static final Map<String, Integer> assignmentNumbers = new HashMap<>();

public static void selectCourses(Student student) {
    JPanel panel = new JPanel(new GridLayout(0, 1));
    JCheckBox[] checkboxes = new JCheckBox[COURSES.length];

    for (int i = 0; i < COURSES.length; i++) {
    checkboxes[i] = new JCheckBox(COURSES[i]);
    if (student.getCourses().contains(COURSES[i])) {
    checkboxes[i].setSelected(true);
            }
panel.add(checkboxes[i]);
        }

int option = JOptionPane.showConfirmDialog(null, panel, "Select Courses",JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (option == JOptionPane.OK_OPTION) {
        student.getCourses().clear();
        courseMarks.clear();
        assignmentNumbers.clear();
        Random random = new Random();

    for (JCheckBox cb : checkboxes) {
        if (cb.isSelected()) {
            String course = cb.getText();
            student.addCourse(course);
            courseMarks.put(course, random.nextInt(41) + 60);
            assignmentNumbers.put(course, random.nextInt(5) + 1);
                }
            }
        }
    }

    public static String getCourseSummary(Student student) {
        if (student.getCourses().isEmpty()) {
            return "No courses enrolled yet.";
        }

        StringBuilder sb = new StringBuilder("\nCourse Summary:\n");

        for (String course : student.getCourses()) {
            sb.append("Course: ").append(course)
        .append("\n| Assignment: Assignment ").append(assignmentNumbers.get(course))
            .append("\n| Marks: ").append(courseMarks.get(course)).append("/100\n\n");
        }

        return sb.toString();
    }

    public static String calculateGPA(Student student) {
        if (student.getCourses().isEmpty()) {
            return "No courses enrolled.";
        }

        double totalPoints = 0;
        int totalCredits = 0;
        StringBuilder result = new StringBuilder();

        for (String course : student.getCourses()) {
            int marks = courseMarks.get(course);
            int credits = COURSE_CREDITS.getOrDefault(course, 3);
            double grade = marksToPoints(marks);

            totalPoints += grade * credits;
            totalCredits += credits;

            result.append(String.format("%s: %d/100 (Grade: %.1f) | Credits: %d\n",
                    course, marks, grade, credits));
        }

        double gpa = totalCredits > 0 ? totalPoints / totalCredits : 0;
        result.append(String.format("\nCGPA: %.2f / 4.00", gpa));
        return result.toString();
    }

    public static Map<String, Integer> getCourseMarks() {
        return new HashMap<>(courseMarks);
    }

    private static double marksToPoints(int marks) {
        if (marks >= 85) return 4.0;
        if (marks >= 80) return 3.7;
        if (marks >= 75) return 3.3;
        if (marks >= 70) return 3.0;
        if (marks >= 65) return 2.7;
        if (marks >= 60) return 2.3;
        return 2.0;
    }
}
