import javax.swing.*;
import java.io.*;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginFrame() {
        setTitle("Login");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        usernameField = new JTextField();
        passwordField = new JPasswordField();

        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);

        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        loginButton.addActionListener(e -> handleLogin());
        registerButton.addActionListener(e -> {
            dispose();
            new RegisterFrame().setVisible(true);
        });

        add(loginButton);
        add(registerButton);
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter both username and password.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
        while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
        if (parts.length >= 2 && parts[0].equals(username) && parts[1].equals(password)) {
                    JOptionPane.showMessageDialog(this, "Login successful!");

        Student student = Student.findByUsername(username);
        if (student == null) {
        JOptionPane.showMessageDialog(this, "Student profile not found.");
        return;
        }

        new Dashboard(student).setVisible(true);
        dispose();
        return;
        }
            }
    JOptionPane.showMessageDialog(this, "Invalid credentials.");}
        catch (IOException e) {
    JOptionPane.showMessageDialog(this, "Could not read user data.");
        }
    }
}
