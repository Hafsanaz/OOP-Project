import javax.swing.*;
import java.awt.*;

public class GPAFrame extends JFrame {

    public GPAFrame(Student student) {
        setTitle("GPA Report - " + student.getName());
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("Academic Report", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        add(title, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JTextArea summaryArea = new JTextArea(CourseManager.getCourseSummary(student));
        summaryArea.setEditable(false);
        summaryArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JTextArea gpaArea = new JTextArea(CourseManager.calculateGPA(student));
        gpaArea.setEditable(false);
        gpaArea.setFont(new Font("Monospaced", Font.BOLD, 14));
        gpaArea.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        mainPanel.add(new JLabel("Course Summary:"));
        mainPanel.add(new JScrollPane(summaryArea));
        mainPanel.add(new JLabel("GPA Calculation:"));
        mainPanel.add(new JScrollPane(gpaArea));

        add(mainPanel, BorderLayout.CENTER);

        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> dispose());
        add(closeBtn, BorderLayout.SOUTH);
    }
}
