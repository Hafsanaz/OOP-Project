import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

public class AttendanceManager {

    public static class AttendanceException extends Exception {
        public AttendanceException(String message) {
            super(message);
        }

        public AttendanceException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    private static AttendanceManager instance;
    private final String filePath;

    private AttendanceManager(String filePath) throws AttendanceException {
        this.filePath = filePath;
        createFileIfMissing();
    }

    public static synchronized AttendanceManager getInstance() throws AttendanceException {
        if (instance == null) {
            instance = new AttendanceManager("attendance.txt");
        }
        return instance;
    }

    private void createFileIfMissing() throws AttendanceException {
        try {
            Path path = Paths.get(filePath);
            if (Files.notExists(path)) {
                Files.createFile(path);
            }
        } catch (IOException e) {
            throw new AttendanceException("Could not setup attendance file", e);
        }
    }

    public interface AttendanceStrategy {
        String formatRecord(Student student);
    }

    public static class DailyAttendance implements AttendanceStrategy {
        public String formatRecord(Student student) {
            return student.getUsername() + "," + LocalDate.now();
        }
    }

    public boolean markAttendance(Student student, AttendanceStrategy strategy) throws AttendanceException {
        String entry = strategy.formatRecord(student);

        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            if (lines.contains(entry)) return false;

            Files.write(Paths.get(filePath), (entry + System.lineSeparator()).getBytes(), StandardOpenOption.APPEND);
            return true;
        } catch (IOException e) {
            throw new AttendanceException("Error writing attendance", e);
        }
    }
}
