import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

public class Dashboard extends JFrame {
    private final Student student;
    private JTextArea output;
    private AttendanceManager attendanceManager;
    private ComplaintManager complaintManager;
    private final JProgressBar progressBar;

    public Dashboard(Student student) {
        this.student = student;

        try {
            attendanceManager = AttendanceManager.getInstance();
            complaintManager = ComplaintManager.getInstance();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Could not initialize system: " + e.getMessage(),
                    "Startup Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);

        initUI();
        complaintManager.addListener((s, msg) -> output.append("Complaint logged: " + msg + "\n"));
    }

    private void initUI() {
        setTitle("Dashboard - " + student.getName());
        setSize(800, 650);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("Welcome to PIEAS, " + student.getName(), JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        output = new JTextArea();
        output.setEditable(false);
        output.setFont(new Font("Monospaced", Font.PLAIN, 14));
        add(new JScrollPane(output), BorderLayout.CENTER);

        add(buildButtonPanel(), BorderLayout.SOUTH);
    }

    private JPanel buildButtonPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 3, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(makeButton("Mark Attendance", Color.BLUE, b -> markAttendance()));
        panel.add(makeButton("Add Courses", Color.ORANGE, b -> {
            CourseManager.selectCourses(student);
            refreshProgress();
        }));
        panel.add(makeButton("View Summary", Color.GREEN, b ->output.append(CourseManager.getCourseSummary(student))));

        panel.add(makeButton("View GPA Report", Color.MAGENTA, b -> openGPA()));
        panel.add(makeButton("Course Progress", Color.CYAN, b -> showProgress()));
        panel.add(makeButton("Submit Complaint", Color.RED, b -> submitComplaint()));

        panel.add(makeButton("Open Calendar", new Color(255, 182, 193), b -> 
            new CalendarFrame().setVisible(true)));
        panel.add(makeButton("Logout", Color.DARK_GRAY, b -> {
            dispose();
            new LoginFrame().setVisible(true);
        }));

        return panel;
    }

    private JButton makeButton(String label, Color color, Consumer<JButton> action) {
        JButton btn = new JButton(label);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.addActionListener(e -> action.accept(btn));
        return btn;
    }

    private void openGPA() {
        if (student.getCourses().isEmpty()) {
            output.append("Please add courses first.\n");
            return;
        }
        if (CourseManager.getCourseMarks().isEmpty()) {
            output.append("Please view summary before GPA.\n");
            return;
        }
        new GPAFrame(student).setVisible(true);
    }

    private void refreshProgress() {
        int total = CourseManager.COURSES.length;
        int completed = (int)((double) student.getCourses().size() / total * 100);
        progressBar.setValue(completed);
    }

    private void showProgress() {
        refreshProgress();
        JOptionPane.showMessageDialog(this,
                new Object[]{
                        "Course completion: " + progressBar.getValue() + "%",
                        progressBar
                },
                "Progress Report",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void markAttendance() {
        try {
            boolean success = attendanceManager.markAttendance(student, new AttendanceManager.DailyAttendance());
            output.append(success ? "Attendance marked.\n" : "Already marked today.\n");
        } catch (AttendanceManager.AttendanceException ex) {
            output.append("Error marking attendance: " + ex.getMessage() + "\n");
        }
    }

    private void submitComplaint() {
        try {
            complaintManager.submitComplaint(student);
        } catch (ComplaintManager.ComplaintException ex) {
            output.append("Complaint failed: " + ex.getMessage() + "\n");
        }
    }
}
