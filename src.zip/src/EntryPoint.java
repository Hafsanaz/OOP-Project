import javax.swing.*;
import java.awt.*;

public class EntryPoint extends JFrame {
    public EntryPoint() {
        setTitle("PIEAS Student System");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 1, 10, 10));
        setLocationRelativeTo(null);

        JLabel label = new JLabel("Welcome to PIEAS System", JLabel.CENTER);
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        loginButton.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        registerButton.addActionListener(e -> {
            dispose();
            new RegisterFrame().setVisible(true);
        });

        add(label);
        add(loginButton);
        add(registerButton);
    }
}
