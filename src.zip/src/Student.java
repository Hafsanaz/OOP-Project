import java.io.*;
import java.util.*;

public class Student {
    private String username;
    private String password;
    private List<String> courses = new ArrayList<>();

    public Student(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
    return username;
    }

    public String getName() {
    return username;
    }

    public String getPassword() {
    return password;
    }

    public List<String> getCourses() {
    return courses;
    }

    public void addCourse(String course) {
        if (!courses.contains(course)) {
            courses.add(course);
        }
    }

    public void saveCourses() {
        try (PrintWriter out = new PrintWriter("courses_" + username + ".txt")) {
            for (String course : courses) {
                out.println(course);
            }
        } catch (IOException e) {
            System.err.println("Could not save courses: " + e.getMessage());
        }
    }

    public void loadCourses() {
        File file = new File("courses_" + username + ".txt");
        if (!file.exists()) return;

        try (BufferedReader in = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = in.readLine()) != null) {
                courses.add(line.trim());
            }
        } catch (IOException e) {
            System.err.println("Could not load courses: " + e.getMessage());
        }
    }

    public static Student findByUsername(String name) {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
        if (parts.length >= 2 && parts[0].equals(name)) {
            Student s = new Student(parts[0], parts[1]);
                    s.loadCourses();
        return s;
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading student data: " + e.getMessage());
        }
        return null;
    }

    public void saveToFile() {
    try (PrintWriter out = new PrintWriter(new FileWriter("users.txt", true))) {
            out.println(username + "," + password);
        } catch (IOException e) {
            System.err.println("Error saving user: " + e.getMessage());
        }
    }
}
