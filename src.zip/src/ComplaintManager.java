import javax.swing.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

public class ComplaintManager {

    public static class ComplaintException extends Exception {
        public ComplaintException(String message) {
            super(message);
        }

        public ComplaintException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    private static ComplaintManager instance;
    private final String filePath;
    private final List<ComplaintListener> listeners = new ArrayList<>();

    private ComplaintManager(String filePath) {
        this.filePath = filePath;
    }

    public static synchronized ComplaintManager getInstance() {
        if (instance == null) {
            instance = new ComplaintManager("complaints.txt");
        }
        return instance;
    }

    public void addListener(ComplaintListener listener) {
        listeners.add(listener);
    }

    public void submitComplaint(Student student) throws ComplaintException {
        String input = JOptionPane.showInputDialog(null, "Enter your complaint:");
        if (input == null || input.trim().isEmpty()) return;

        String entry = String.format("[%s] %s: %s", new Date(), student.getUsername(), input.trim());

        try {
            Path path = Paths.get(filePath);
            Files.write(path, Collections.singletonList(entry), StandardOpenOption.CREATE, StandardOpenOption.APPEND);

            notifyListeners(student, input);
            JOptionPane.showMessageDialog(null, "Complaint submitted.");
        } catch (IOException e) {
            throw new ComplaintException("Error writing complaint", e);
        }
    }

    private void notifyListeners(Student student, String complaint) {
        for (ComplaintListener listener : listeners) {
            listener.onComplaintSubmitted(student, complaint);
        }
    }

    public interface ComplaintListener {
        void onComplaintSubmitted(Student student, String complaint);
    }
}
