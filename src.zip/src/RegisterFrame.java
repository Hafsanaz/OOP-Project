import javax.swing.*;
import java.io.*;

public class RegisterFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public RegisterFrame() {
        setTitle("Register");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        usernameField = new JTextField();
        passwordField = new JPasswordField();

        add(new JLabel("Choose Username:"));
        add(usernameField);
        add(new JLabel("Choose Password:"));
        add(passwordField);

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(e -> handleRegister());
        add(registerButton);
    }

    private void handleRegister() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username and password cannot be empty.");
        return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
        while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
        if (parts.length >= 2 && parts[0].equals(username)) {
                    JOptionPane.showMessageDialog(this, "Username already exists.");
        return;
                }
            }
        } catch (IOException ignored) {}

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
            writer.write(username + "," + password);
            writer.newLine();
            JOptionPane.showMessageDialog(this, "Registration successful! You can now login.");
            dispose();
            new LoginFrame().setVisible(true);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Could not save user information.");
        }
    }
}
